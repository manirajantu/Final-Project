// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyAnOpkk5VB3fM1supYpJjzAvcLkJ0QQ66k",
  authDomain: "expensereactnative-b8ec4.firebaseapp.com",
  projectId: "expensereactnative-b8ec4",
  storageBucket: "expensereactnative-b8ec4.appspot.com",
  messagingSenderId: "707368538811",
  appId: "1:707368538811:web:0b30b15f312086d1f90f9e"
};

